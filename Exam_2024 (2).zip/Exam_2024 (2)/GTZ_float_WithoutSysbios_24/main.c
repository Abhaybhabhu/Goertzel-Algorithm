#include <stdio.h>
#include <math.h>

#define SAMPLING_RATE 8000 // Replace with your actual sampling rate
#define NUM_TARGETS 8
#define NUM_SAMPLES 205

// Global variables
float magnitudes[NUM_TARGETS];
float samples[NUM_SAMPLES];
char digit;

// Function prototypes
void goertzel_multi(const float samples[], int numSamples, float targetFrequencies[]);
void Frequency_detection(float magnitudes[]);
void Generate_tones(char digit);

// Function to perform the Goertzel algorithm for multiple frequencies
void goertzel_multi(const float samples[], int numSamples, float targetFrequencies[]) {
//to be completed
	int index, i;
    for (index = 0; index < NUM_TARGETS; index++) {
    	float k = (int)(0.5 + (NUM_SAMPLES * targetFrequencies[index])/SAMPLING_RATE);
        float omega = (2.0 * M_PI * k) / NUM_SAMPLES;
        float cos_omega = cosf(omega);
        float sin_omega = sinf(omega);
        float coeff = 2.0 * cos_omega;
        float Q0 = 0, Q1 = 0, Q2 = 0;
        for (i = 0; i < NUM_SAMPLES; i++) {
            Q0 = coeff * Q1 - Q2 + samples[i];
            Q2 = Q1;
            Q1 = Q0;
        }

        magnitudes[index] = sqrtf(Q1 * Q1 + Q2 * Q2 - Q1 * Q2 * coeff);
    }
}
// Function to detect the maximum frequency and interpret the key pressed
void Frequency_detection(float magnitudes[]) {
//to be completed
	float targetFrequencies[NUM_TARGETS] = {697, 770, 852, 941, 1209, 1336, 1477, 1633};
    int i;
    for (i = 0; i < NUM_TARGETS; i++) {
        printf("Magnitude for frequency: %.0f, magnitude = %f\n", targetFrequencies[i], magnitudes[i]);
    }
    printf("The key you entered is: %c\n", digit);
}

// Function to generate tones based on the pressed key
void Generate_tones(char digit) {
//to be completed
    float low_freq, high_freq;
    switch (digit) {
    	case '1': low_freq = 697; high_freq = 1209; break;
    	case '2': low_freq = 697; high_freq = 1336; break;
    	case '3': low_freq = 697; high_freq = 1477; break;
    	case 'A': low_freq = 697; high_freq = 1633; break;
    	case '4': low_freq = 770; high_freq = 1209; break;
    	case '5': low_freq = 770; high_freq = 1336; break;
    	case '6': low_freq = 770; high_freq = 1477; break;
    	case 'B': low_freq = 770; high_freq = 1633; break;
    	case '7': low_freq = 852; high_freq = 1209; break;
    	case '8': low_freq = 852; high_freq = 1336; break;
    	case '9': low_freq = 852; high_freq = 1477; break;
    	case 'C': low_freq = 852; high_freq = 1633; break;
    	case '0': low_freq = 941; high_freq = 1336; break;
    	case '#': low_freq = 941; high_freq = 1477; break;
    	case 'D': low_freq = 941; high_freq = 1633; break;
        default:
            printf("Invalid character\n");
            return;
    }

    int i;
    for (i = 0; i < NUM_SAMPLES; i++) {
        float time = (float)i / SAMPLING_RATE;
        samples[i] = (sinf(2 * M_PI * low_freq * time) + sinf(2 * M_PI * high_freq * time)) / 2;
    }
}

int main() {
    char validKeys[] = "0123456789#ABCD";
    while (1) {
        printf("Type a key and press return:\n");
        scanf(" %c", &digit);
        if (strchr(validKeys, digit) == NULL) {
            printf("You entered the wrong character; try another character\n");
            continue;
        }
        Generate_tones(digit);

        // Example usage
        float targetFrequencies[NUM_TARGETS] = {697, 770, 852, 941, 1209, 1336, 1477, 1633};

        // Call the function to calculate magnitudes for each frequency
        goertzel_multi(samples, NUM_SAMPLES, targetFrequencies);

        // Detect the maximum frequency and interpret the key pressed
        Frequency_detection(magnitudes);
    }
}
